import React from 'react'

const Footer = () => {
  return (
    <div className='text-white'>
      Footer
    </div>
  )
}

export default Footer
